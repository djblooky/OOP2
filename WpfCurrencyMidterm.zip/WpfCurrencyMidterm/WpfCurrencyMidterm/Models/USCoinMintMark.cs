﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfCurrencyMidterm.Models
{
    public enum USCoinMintMark
    {
        P,
        D,
        S,
        W
    }
}
