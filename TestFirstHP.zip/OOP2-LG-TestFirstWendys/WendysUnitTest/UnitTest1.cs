﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OOP2_LG_TestFirstWendys;

namespace WendysUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        public Wendys wendys;

        [TestMethod]
        public void RestaurantTests()
        {
            // Arrange
            wendys = new Wendys();
            // Act
            wendys.Close();
            bool wendysClosed = wendys.IsOpen;
            wendys.Open();
            bool wendysOpen = wendys.IsOpen;
            wendys.Hire(new Employee());
            int hiredOneEmployee = wendys.Employees.Count;
            wendys.Fire(wendys.Employees[0]);
            int firedOneEmployee = wendys.Employees.Count;
            wendys.Fire(new Employee()); // Should fail
            int failedFire = wendys.Employees.Count;
            wendys.Hire(new Employee()); //added in employee (HP)
            wendys.Serve(wendys.Employees[0]);
            int stockAfterOneServe = wendys.CurrentStock;
            wendys.Serve(new Employee()); // Should fail
            int stockAfterFailedServe = wendys.CurrentStock;
            wendys.Restock();
            int stockAfterRestock = wendys.CurrentStock;
            // Assert
            Assert.AreEqual(false, wendysClosed);
            Assert.AreEqual(true, wendysOpen);
            Assert.AreEqual(1, hiredOneEmployee); //changed from 2 to 1 (HP)
            Assert.AreEqual(0, firedOneEmployee); //changed from 1 to 0 (HP)
            Assert.AreEqual(0, failedFire);  //changed from 1 to 0 (HP)
            Assert.AreEqual(99, stockAfterOneServe);
            Assert.AreEqual(99, stockAfterFailedServe); 
            Assert.AreEqual(100, stockAfterRestock);
        }
    }
}
