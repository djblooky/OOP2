﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOP2_LG_TestFirstWendys;

namespace OOP2_LG_TestFirstWendys
{
    public abstract class Restaurant
    {
        public bool IsOpen;
        public int CurrentStock;
        public List<Employee> Employees;
        
        private int defaultStock;

        public Restaurant()
        {
            defaultStock = 100;
            Employees = new List<Employee>();
            Restock();
        }

        public void Open()
        {
            IsOpen = true;
        }

        public void Close()
        {
            IsOpen = false;
        }

        public void Hire(Employee e)
        {
            Employees.Add(e);
        }

        public void Fire(Employee e)
        {
            if (Employees.Contains(e))
            {
                Employees.Remove(e);
            }
        }

        public void Serve(Employee e)
        {
            if (IsOpen && CurrentStock > 0 && Employees.Contains(e))
            {
                CurrentStock = e.ServeFood(CurrentStock);
            }   
        }

        public void Restock()
        {
            CurrentStock = defaultStock;
        }
    }
}
